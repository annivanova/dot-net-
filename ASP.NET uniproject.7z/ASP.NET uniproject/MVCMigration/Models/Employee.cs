﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MVCMigration.Models
{
    public enum Gender { Male, Female}
    public class Employee
    {
        [Key]
        public int EmpId { get; set; }
        [Display(Name ="Employee Name")]
        [Required]
        public string EmpName { get; set; }
        [Required]
        public Gender? Gender { get; set; }
        [Required]
        [Display(Name = "Department")]
        public int DepartmentId { get; set; }

        public virtual Department departmentName { get; set; }
    }
    public class Department {
        [Key]
        public int DepartmentId { get; set; }
        [Required]
        [Display(Name = "Department Name")]
        public string DepartmentName { get; set; }
    }
}